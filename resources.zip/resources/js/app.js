
import './utils.js';
import './bootstrap';
////este como tal sera el conflicto que  que hay ahora en main esta esto 
// CSS
import '../css/app.css';
import '../css/form.css';
import '../css/gestion.css';
import '../css/technologies.css';
import '../css/dashboard.css';
import '../css/knowledge.css';
import '../css/tabla-gestion.css';
import '../css/login.css';
import '../css/register.css';
import '../css/editprofile.css';
import '../css/english.css';
import '../css/english-study.css';
import '../css/english-practice.css';
import '../css/english-statistics.css';
import '../css/english-dominio.css';
import '../css/manuals.css';
import '../css/manuals-execution.css';
import '../css/manuals-mio.css';
import '../css/hellad.css';
import '../css/planificacion-crear.css';
import '../css/planificaciones.css';
import '../css/grammar.css';
import '../css/grammar-category.css';
import '../css/grammar-topic.css';
import '../css/grammar-lesson.css';
import '../css/admin/grammar-import.css';
import '../css/admin/english-import.css';
// JavaScript

import './form.js';
import './technologies.js';
import './concepts.js';
import './categories.js';
import './tabla-gestion.js';
import './dashboard.js';
import './english-categories.js';
import './english-words.js';
import './english-meanings.js';
import './pronunciation.js';
import './gemini-live.js';
import './english-study.js';
import './english-index.js';
import './english-practice.js';
import './manuals.js';
import './manual-sections.js';
import './manual-steps.js';
import './manual-mio.js';
import './manual-execution.js';
import './planificaciones.js';
import './planificacion-crear.js';
import './english-pronunciation.js';
import './grammar-lesson.js';
import './admin/grammar-import.js';
import './admin/english-import.js';





