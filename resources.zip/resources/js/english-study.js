const study = window.englishStudy;

if (study) {

    let currentIndex = 0;

    // Mezclar las palabras aleatoriamente
    study.words.sort(() => Math.random() - 0.5);

    const progress =
        document.getElementById('study-progress');

    const currentWordElement =
        document.getElementById('study-current-word');

    const pronunciationGuide =
        document.getElementById('study-pronunciation-guide');

    const pronunciationText =
        document.getElementById('study-pronunciation-text');

    const pronunciationButton =
        pronunciationGuide?.querySelector(
            '.btn-study-pronunciation'
        );

    const meanings =
        document.getElementById('study-meanings');

    const example =
        document.getElementById('study-example');

    const exampleText =
        document.getElementById('study-example-text');

    const examplePronunciationButton =
        example?.querySelector(
            '.btn-study-example-pronunciation'
        );

    const exampleTranslation =
        document.getElementById(
            'study-example-translation'
        );

    const previousButton =
        document.getElementById(
            'btn-previous-word'
        );

    const nextButton =
        document.getElementById(
            'btn-next-word'
        );

    const completedGroup =
        document.getElementById(
            'study-completed-group'
        );



    function reproducirPalabraAutomaticamente() {

        if (!pronunciationButton) {
            return;
        }

        const palabra =
            pronunciationButton.dataset.word;

        if (!palabra) {
            return;
        }

        /*
        |--------------------------------------------------------------
        | Pequeña espera para asegurarnos de que el contenido
        | ya fue actualizado en pantalla.
        |--------------------------------------------------------------
        */

        setTimeout(() => {

            pronunciationButton.click();

        }, 250);

    }



    function renderWord() {

        const word =
            study.words[currentIndex];

        if (!word) {
            return;
        }



        if (progress) {

            progress.textContent =
                `${currentIndex + 1} / ${study.words.length}`;

        }



        if (currentWordElement) {

            currentWordElement.textContent =
                word.word || '';

        }



        if (pronunciationGuide) {

            if (word.pronunciation_guide) {

                pronunciationGuide.style.display =
                    'flex';
                if (pronunciationText) {

                    const ipa =
                        word.pronunciation_guide || '';

                    const guia =
                        typeof window.convertirPronunciacion === 'function'
                            ? window.convertirPronunciacion(
                                word.word,
                                ipa
                            ).replace(/^\/|\/$/g, '')
                            : '';

                    pronunciationText.textContent =
                        `${ipa} | ${guia}`;
                }

            } else {

                pronunciationGuide.style.display =
                    'none';

                if (pronunciationText) {

                    pronunciationText.textContent =
                        '';

                }

            }

        }



        if (pronunciationButton) {

            pronunciationButton.dataset.word =
                word.word || '';

        }



        if (meanings) {

            meanings.innerHTML = '';

            if (
                word.meanings &&
                Array.isArray(word.meanings)
            ) {

                word.meanings.forEach(
                    meaning => {

                        const p =
                            document.createElement('p');

                        p.textContent =
                            meaning.meaning || '';

                        meanings.appendChild(p);

                    }
                );

            }

        }



        if (example) {

            if (word.example) {

                example.style.display =
                    'flex';

                if (exampleText) {

                    exampleText.textContent =
                        word.example;

                }



                if (examplePronunciationButton) {

                    examplePronunciationButton.dataset.example =
                        word.example;

                }



                if (exampleTranslation) {

                    if (word.example_translation) {

                        exampleTranslation.style.display =
                            'block';

                        exampleTranslation.textContent =
                            word.example_translation;

                    } else {

                        exampleTranslation.style.display =
                            'none';

                        exampleTranslation.textContent =
                            '';

                    }

                }

            } else {

                example.style.display =
                    'none';

                if (exampleText) {

                    exampleText.textContent =
                        '';

                }

                if (examplePronunciationButton) {

                    examplePronunciationButton.dataset.example =
                        '';

                }

                if (exampleTranslation) {

                    exampleTranslation.style.display =
                        'none';

                    exampleTranslation.textContent =
                        '';

                }

            }

        }



        if (previousButton) {

            previousButton.style.display =
                currentIndex > 0
                    ? 'inline-block'
                    : 'none';

        }



        if (nextButton) {

            nextButton.style.display =
                currentIndex < study.words.length - 1
                    ? 'inline-block'
                    : 'none';

        }



        if (completedGroup) {

            completedGroup.style.display =
                currentIndex === study.words.length - 1
                    ? 'flex'
                    : 'none';

        }



        study.currentIndex =
            currentIndex;


        /*
        |--------------------------------------------------------------------------
        | 🔊 REPRODUCCIÓN AUTOMÁTICA
        |--------------------------------------------------------------------------
        |
        | Cada vez que aparece una palabra nueva:
        | - Se muestra normalmente.
        | - Se actualiza su pronunciación.
        | - Se reproduce automáticamente una sola vez.
        |
        */

        reproducirPalabraAutomaticamente();

    }



    previousButton?.addEventListener(
        'click',
        () => {

            if (currentIndex <= 0) {
                return;
            }

            currentIndex--;

            renderWord();

        }
    );



    nextButton?.addEventListener(
        'click',
        () => {

            if (
                currentIndex >=
                study.words.length - 1
            ) {
                return;
            }

            currentIndex++;

            renderWord();

        }
    );












    renderWord();

}