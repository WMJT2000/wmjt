
(() => {
    const practice = window.englishPractice;
    if (!practice) return;
    let questions = [];
    let currentQuestionIndex = 0;
    let score = 0;
    let answered = false;
    let autoNextEnabled = true;
    let autoNextTimer = null;
    let feedbackCompletionToken = 0;
    let feedbackTimer = null;
    let retryTimer = null;
    let selectedPracticeMode = null;
    let practiceSoundsEnabled = true;
    let audioContext = null;
    const practiceCard = document.getElementById('practice-card');
    const practiceResult = document.getElementById('practice-result');
    const modeSelector = document.getElementById('practice-mode-selector');
    const modeOptions = document.querySelectorAll('.english-practice-mode-option');
    const startButton = document.getElementById('btn-start-practice');
    const progress = document.getElementById('practice-progress');
    const questionType = document.getElementById('practice-question-type');
    const question = document.getElementById('practice-question');
    const listenContainer = document.getElementById('practice-listen');
    const options = document.getElementById('practice-options');
    const feedback = document.getElementById('practice-feedback');
    const feedbackTitle = document.getElementById('practice-feedback-title');
    const feedbackText = document.getElementById('practice-feedback-text');
    const nextButton = document.getElementById('btn-next-practice');
    const autoNextButton = document.getElementById('btn-toggle-auto-next');
    const soundToggle = document.getElementById('btn-toggle-practice-sounds');
    const retryButton = document.getElementById('btn-retry-practice');
    const changeModeButton = document.getElementById('btn-change-practice-mode');
    const exitPracticeButton = document.getElementById('btn-exit-practice');
    const scoreElement = document.getElementById('practice-score');
    const resultMessageElement = document.getElementById('practice-result-message');
    const resultCategoryElement = document.getElementById('practice-result-category');
    const correctAnswersElement = document.getElementById('practice-correct-answers');
    const incorrectAnswersElement = document.getElementById('practice-incorrect-answers');

    modeOptions.forEach(option => {
        option.addEventListener('click', () => {
            if (option.disabled) return;
            modeOptions.forEach(item => item.classList.remove('selected'));
            option.classList.add('selected');
            selectedPracticeMode = option.dataset.practiceMode;
            practice.selectedMode = selectedPracticeMode;
            if (startButton) startButton.disabled = false;
        });
    });

    const questionCountOptions = document.querySelectorAll('.english-practice-question-count-option');

    questionCountOptions.forEach(option => {
        option.addEventListener('click', () => {
            questionCountOptions.forEach(item => item.classList.remove('selected'));
            option.classList.add('selected');
            practice.questionCount = parseInt(option.dataset.questionCount, 10);
        });
    });

    function mezclar(array) {
        return [...array].sort(() => Math.random() - 0.5);
    }

    function obtenerAudioContext() {
        if (!audioContext) audioContext = new (window.AudioContext || window.webkitAudioContext)();
        if (audioContext.state === 'suspended') audioContext.resume();
        return audioContext;
    }

    function reproducirSonidoCorrecto() {
        if (!practiceSoundsEnabled) return;
        const context = obtenerAudioContext();
        const ahora = context.currentTime;
        const oscillator = context.createOscillator();
        const gain = context.createGain();
        oscillator.type = 'sine';
        oscillator.frequency.setValueAtTime(523.25, ahora);
        oscillator.frequency.setValueAtTime(659.25, ahora + 0.10);
        oscillator.frequency.setValueAtTime(783.99, ahora + 0.20);
        gain.gain.setValueAtTime(0.0001, ahora);
        gain.gain.exponentialRampToValueAtTime(0.25, ahora + 0.02);
        gain.gain.exponentialRampToValueAtTime(0.0001, ahora + 0.35);
        oscillator.connect(gain);
        gain.connect(context.destination);
        oscillator.start(ahora);
        oscillator.stop(ahora + 0.35);
    }

    function reproducirSonidoIncorrecto() {
        if (!practiceSoundsEnabled) return;
        const context = obtenerAudioContext();
        const ahora = context.currentTime;
        const oscillator = context.createOscillator();
        const gain = context.createGain();
        oscillator.type = 'sine';
        oscillator.frequency.setValueAtTime(220, ahora);
        oscillator.frequency.exponentialRampToValueAtTime(130, ahora + 0.25);
        gain.gain.setValueAtTime(0.0001, ahora);
        gain.gain.exponentialRampToValueAtTime(0.20, ahora + 0.02);
        gain.gain.exponentialRampToValueAtTime(0.0001, ahora + 0.30);
        oscillator.connect(gain);
        gain.connect(context.destination);
        oscillator.start(ahora);
        oscillator.stop(ahora + 0.30);
    }

    if (soundToggle) {
        soundToggle.addEventListener('click', () => {
            practiceSoundsEnabled = !practiceSoundsEnabled;
            soundToggle.setAttribute('aria-pressed', practiceSoundsEnabled ? 'false' : 'true');
            if (practiceSoundsEnabled) {
                soundToggle.textContent = '🔊 Sonidos';
                soundToggle.classList.remove('muted');
            } else {
                soundToggle.textContent = '🔇 Sonidos';
                soundToggle.classList.add('muted');
            }
        });
    }


    function obtenerSignificados(word) {
        if (!word.meanings || word.meanings.length === 0) return [];

        return word.meanings
            .map(item => item.meaning)
            .filter(Boolean);
    }

    function obtenerSignificado(word) {
        return obtenerSignificados(word)[0] || null;
    }


    function obtenerPalabrasPorSignificado(significado) {
        const clave = normalizarRespuesta(significado);

        return practice.words.filter(word =>
            obtenerSignificados(word).some(item =>
                normalizarRespuesta(item) === clave
            )
        );
    }



    function obtenerPalabrasConSignificado() {
        return practice.words.filter(word => word.meanings && word.meanings.length > 0);
    }

    function normalizarRespuesta(texto) {
        return String(texto || '').trim().toLowerCase().replace(/\s+/g, ' ');
    }

    function crearOracionIncompleta(oracion, palabra) {
        const palabraEscapada = palabra.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
        const expresion = new RegExp(`\\b${palabraEscapada}\\b`, 'i');
        return oracion.replace(expresion, '____');
    }

    function crearOpciones(respuestasCorrectas, obtenerRespuesta) {
        const correctas = Array.isArray(respuestasCorrectas)
            ? respuestasCorrectas
            : [respuestasCorrectas];

        const opciones = [];
        const opcionesVistas = new Set();

        const agregarOpcion = (respuesta) => {
            if (!respuesta) return;

            const clave = normalizarRespuesta(respuesta);
            if (opcionesVistas.has(clave)) return;

            opcionesVistas.add(clave);
            opciones.push(respuesta);
        };

        correctas.forEach(agregarOpcion);

        const candidatos = mezclar(practice.words);
        for (const word of candidatos) {
            agregarOpcion(obtenerRespuesta(word));
            if (opciones.length >= 4) break;
        }

        return mezclar(opciones);
    }

    function crearPregunta(word, tipo) {

        if (tipo === 'english-spanish') {
            const significados = obtenerSignificados(word);
            if (significados.length === 0) return null;

            const respuestaCorrecta = significados[0];

            return {
                type: 'english-spanish',
                typeLabel: 'Inglés → Español',
                question: word.word,
                pronunciationGuide: word.pronunciation_guide || '',
                correctAnswer: respuestaCorrecta,
                correctAnswers: significados,
                answerLanguage: 'es-ES',
                meaning: significados.join(', '),
                wordId: word.id,
                options: crearOpciones(significados, obtenerSignificado)
            };
        }


        if (tipo === 'spanish-english') {
            const significado = obtenerSignificado(word);
            if (!significado) return null;

            const respuestasCorrectas = [
                ...new Map(
                    obtenerPalabrasPorSignificado(significado).map(item => [
                        normalizarRespuesta(item.word),
                        item.word
                    ])
                ).values()
            ];

            return {
                type: 'spanish-english',
                typeLabel: 'Español → Inglés',
                question: significado,
                correctAnswer: word.word,
                correctAnswers: respuestasCorrectas,
                answerLanguage: 'en-US',
                meaning: significado,
                wordId: word.id,
                options: crearOpciones(respuestasCorrectas, item => item.word)
            };
        }

        if (tipo === 'listening') {
            return {
                type: 'listening',
                typeLabel: 'Escucha → Escribe',
                question: 'Escucha la palabra y escríbela.',
                correctAnswer: word.word,
                answerLanguage: 'en-US',
                meaning: obtenerSignificado(word),
                wordId: word.id
            };
        }


        if (tipo === 'english-meaning') {
            const significados = obtenerSignificados(word);
            if (significados.length === 0) return null;

            return {
                type: 'english-meaning',
                typeLabel: 'Inglés → Escribir significado',
                question: word.word,
                pronunciationGuide: word.pronunciation_guide || '',
                correctAnswer: significados[0],
                correctAnswers: significados,
                answerLanguage: 'es-ES',
                meaning: significados.join(', '),
                wordId: word.id
            };
        }


        if (tipo === 'spanish-word') {
            const significado = obtenerSignificado(word);

            if (!significado) return null;

            const respuestasCorrectas = [
                ...new Map(
                    obtenerPalabrasPorSignificado(significado).map(item => [
                        normalizarRespuesta(item.word),
                        item.word
                    ])
                ).values()
            ];

            return {
                type: 'spanish-word',
                typeLabel: 'Español → Escribir inglés',
                question: significado,
                correctAnswer: word.word,
                correctAnswers: respuestasCorrectas,
                answerLanguage: 'en-US',
                meaning: significado,
                wordId: word.id
            };
        }


        if (tipo === 'sentence' && word.example) {
            const oracionIncompleta = crearOracionIncompleta(word.example, word.word);
            if (oracionIncompleta === word.example) return null;
            return {
                type: 'sentence',
                typeLabel: 'Completar oración',
                question: oracionIncompleta,
                correctAnswer: word.word,
                answerLanguage: 'en-US',
                wordId: word.id,
                options: crearOpciones(word.word, item => item.word)
            };
        }

        return null;
    }

    function generarPreguntas() {
        let palabras = [...practice.words];

        if (selectedPracticeMode === 'incorrect') {
            const incorrectWordIds = practice.incorrectWordIds || [];
            palabras = palabras.filter(word => incorrectWordIds.includes(word.id));
        }

        if (selectedPracticeMode !== 'listening') {
            palabras = palabras.filter(word => word.meanings && word.meanings.length > 0);
        }

        if (palabras.length === 0) {
            console.warn('NO HAY PALABRAS DISPONIBLES');
            return [];
        }

        const totalQuestions = Math.min(practice.questionCount, palabras.length);

        function obtenerPeso(word) {
            const stats = practice.wordPracticeStats?.[word.id];
            if (!stats || stats.total === 0) return 3;
            if (stats.accuracy < 50) return 6;
            if (stats.accuracy < 80) return 4;
            if (stats.total < 5) return 3;
            return 1;
        }

        function seleccionarPalabrasPonderadas(palabrasDisponibles, cantidad) {
            const seleccionadas = [];
            const candidatos = [...palabrasDisponibles];

            while (candidatos.length > 0 && seleccionadas.length < cantidad) {
                let pesoTotal = 0;

                candidatos.forEach(word => {
                    pesoTotal += obtenerPeso(word);
                });

                let objetivo = Math.random() * pesoTotal;
                let seleccionada = null;

                for (const word of candidatos) {
                    objetivo -= obtenerPeso(word);

                    if (objetivo <= 0) {
                        seleccionada = word;
                        break;
                    }
                }

                if (!seleccionada) break;

                seleccionadas.push(seleccionada);

                const index = candidatos.indexOf(seleccionada);
                if (index !== -1) candidatos.splice(index, 1);
            }

            return seleccionadas;
        }

        const palabrasSeleccionadas = seleccionarPalabrasPonderadas(palabras, totalQuestions);

        let tipos = [];

        if (selectedPracticeMode === 'english-spanish') {
            tipos = ['english-spanish'];
        } else if (selectedPracticeMode === 'spanish-english') {
            tipos = ['spanish-english'];
        } else if (selectedPracticeMode === 'listening') {
            tipos = ['listening'];
        } else if (selectedPracticeMode === 'english-meaning') {
            tipos = ['english-meaning'];
        } else if (selectedPracticeMode === 'spanish-word') {
            tipos = ['spanish-word'];
        } else if (selectedPracticeMode === 'mixed') {
            tipos = ['english-spanish', 'spanish-english', 'listening', 'english-meaning', 'spanish-word'];
        } else if (selectedPracticeMode === 'incorrect') {
            tipos = ['english-spanish', 'spanish-english', 'listening', 'english-meaning', 'spanish-word'];
        }

        if (tipos.length === 0) {
            console.error('NO HAY TIPOS DE PREGUNTA PARA:', selectedPracticeMode);
            return [];
        }

        const resultado = [];

        palabrasSeleccionadas.forEach(word => {
            const tiposDisponibles = mezclar(tipos);
            let pregunta = null;

            for (const tipo of tiposDisponibles) {
                pregunta = crearPregunta(word, tipo);

                if (pregunta) break;
            }

            if (pregunta) resultado.push(pregunta);
        });

        return resultado;
    }
    function mostrarPregunta() {
        const current = questions[currentQuestionIndex];

        if (!current) {
            finalizarPractica();
            return;
        }

        if (autoNextTimer) {
            clearTimeout(autoNextTimer);
            autoNextTimer = null;
        }

        cancelarReintentoPendiente();

        answered = false;
        questionType.style.display = '';
        question.style.display = '';
        options.style.display = '';
        listenContainer.style.display = 'none';
        progress.textContent = `${currentQuestionIndex + 1} / ${questions.length}`;
        questionType.textContent = current.typeLabel;
        question.textContent = '';

        if (current.type === 'english-spanish' || current.type === 'english-meaning') {
            const questionContent = document.createElement('div');
            questionContent.className = 'english-practice-question-word';

            const wordText = document.createElement('span');
            wordText.textContent = current.question;

            const pronunciationButton = document.createElement('button');
            pronunciationButton.type = 'button';
            pronunciationButton.className = 'english-practice-pronunciation-button';
            pronunciationButton.textContent = '🔊';
            pronunciationButton.setAttribute('aria-label', 'Reproducir pronunciación');
            pronunciationButton.addEventListener('click', () => {
                reproducirPalabra(current.question);
            });

            const pronunciationToggle = document.createElement('button');
            pronunciationToggle.type = 'button';
            pronunciationToggle.className = 'english-practice-pronunciation-toggle';
            pronunciationToggle.textContent = '⌄';
            pronunciationToggle.setAttribute('aria-expanded', 'true');
            pronunciationToggle.textContent = '⌃';
            const pronunciationGuide = document.createElement('div');
            pronunciationGuide.className = 'english-practice-pronunciation-guide';

            const ipa = current.pronunciationGuide || '';

            if (typeof window.convertirPronunciacion === 'function') {
                const guia = window.convertirPronunciacion(current.question, ipa);
                pronunciationGuide.textContent = `${ipa} | ${guia.replace(/^\/|\/$/g, '')}`;
            } else {
                pronunciationGuide.textContent = ipa;
            }

            pronunciationGuide.style.display = 'block';

            pronunciationToggle.addEventListener('click', () => {
                const visible = pronunciationGuide.style.display !== 'none';
                pronunciationGuide.style.display = visible ? 'none' : 'block';
                pronunciationToggle.textContent = visible ? '⌄' : '⌃';
                pronunciationToggle.setAttribute('aria-expanded', visible ? 'false' : 'true');
            });

            const buttons = document.createElement('div');
            buttons.className = 'english-practice-pronunciation-actions';
            buttons.appendChild(pronunciationButton);
            buttons.appendChild(pronunciationToggle);

            questionContent.appendChild(wordText);
            questionContent.appendChild(buttons);
            question.appendChild(questionContent);
            question.appendChild(pronunciationGuide);
        } else {
            question.textContent = current.question;
        }

        options.innerHTML = '';

        if (current.type === 'listening' || current.type === 'english-meaning' || current.type === 'spanish-word') {
            options.style.display = 'block';

            const answerWrapper = document.createElement('div');
            answerWrapper.className = 'english-practice-listening-answer';

            if (current.type === 'listening') {
                const listenButton = document.createElement('button');
                listenButton.type = 'button';
                listenButton.className = 'english-practice-listen';
                listenButton.textContent = '🔊 Escuchar';
                listenButton.addEventListener('click', () => {
                    reproducirPalabra(current.correctAnswer);
                });
                answerWrapper.appendChild(listenButton);
            }

            const input = document.createElement('input');
            input.type = 'text';
            input.className = 'english-practice-answer-input';
            input.placeholder = current.type === 'english-meaning' ? 'Escribe el significado...' : current.type === 'spanish-word' ? 'Escribe la palabra en inglés...' : 'Escribe la palabra...';
            input.autocomplete = 'off';
            input.autocapitalize = 'none';
            input.spellcheck = false;
            input.setAttribute('aria-label', current.type === 'english-meaning' ? 'Escribe el significado' : current.type === 'spanish-word' ? 'Escribe la palabra en inglés' : 'Escribe la palabra que escuchaste');

            const answerButton = document.createElement('button');
            answerButton.type = 'button';
            answerButton.className = 'english-practice-submit-answer';
            answerButton.textContent = 'Responder';

            const enviarRespuesta = () => {
                if (answered) return;

                const respuesta = input.value.trim();

                if (!respuesta) {
                    input.focus();
                    return;
                }

                responder(respuesta, answerButton, current);
            };

            answerButton.addEventListener('click', enviarRespuesta);

            input.addEventListener('keydown', event => {
                if (event.key === 'Enter') {
                    event.preventDefault();
                    enviarRespuesta();
                }
            });

            answerWrapper.appendChild(input);
            answerWrapper.appendChild(answerButton);
            options.appendChild(answerWrapper);

            if (current.type === 'listening') {
                setTimeout(() => {
                    if (!answered) reproducirPalabra(current.correctAnswer);
                }, 300);
            } else if (current.type === 'english-meaning') {
                setTimeout(() => {
                    if (!answered) reproducirPalabra(current.question);
                }, 300);
            }

            setTimeout(() => {
                if (!answered) input.focus();
            }, 500);
        }

        if (current.type !== 'listening' && current.type !== 'english-meaning' && current.type !== 'spanish-word') {
            current.options.forEach(opcion => {
                const button = document.createElement('button');
                button.type = 'button';
                button.className = 'english-practice-option';
                button.textContent = opcion;
                button.addEventListener('click', () => {
                    responder(opcion, button, current);
                });
                options.appendChild(button);
            });
        }

        feedback.style.display = 'none';
        nextButton.style.display = 'none';

        if (current.type === 'english-spanish') {
            setTimeout(() => {
                if (!answered) reproducirPalabra(current.question);
            }, 300);
        }
    }

    async function iniciarSesion() {
        const response = await fetch(`/english/category/${practice.categoryId}/practice/start`, {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
                'Accept': 'application/json',
                'X-CSRF-TOKEN': document.querySelector('meta[name="csrf-token"]').getAttribute('content')
            },
            body: JSON.stringify({
                practice_session_id: practice.sessionId,
                practice_mode: practice.selectedMode
            })
        });

        const data = await response.json();

        if (!response.ok) {
            throw new Error(data.message || 'No se pudo iniciar la práctica.');
        }

        return data;
    }

    async function guardarResultado(current, respuesta) {
        if (!current.wordId) {
            console.error('La pregunta no tiene wordId.');
            return;
        }


        const respuestasCorrectas = current.correctAnswers || [current.correctAnswer];

        const correcta = respuestasCorrectas.some(
            respuestaCorrecta =>
                normalizarRespuesta(respuesta) === normalizarRespuesta(respuestaCorrecta)
        );

        const response = await fetch(`/english/category/${practice.categoryId}/practice/result`, {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
                'Accept': 'application/json',
                'X-CSRF-TOKEN': document.querySelector('meta[name="csrf-token"]').getAttribute('content')
            },
            body: JSON.stringify({
                english_word_id: current.wordId,
                practice_session_id: practice.sessionId,
                question_type: current.type,
                user_answer: respuesta,
                correct_answer: current.correctAnswer,
                is_correct: correcta
            })
        });

        if (!response.ok) throw new Error('No se pudo guardar la respuesta.');

        return response.json();
    }

    function programarAutoNext(tiempo = 0) {
        if (!autoNextEnabled) return;

        if (autoNextTimer) {
            clearTimeout(autoNextTimer);
        }

        autoNextTimer = setTimeout(() => {
            autoNextTimer = null;
            avanzarSiguiente();
        }, tiempo);
    }

    function cancelarReintentoPendiente() {
        if (retryTimer) {
            clearTimeout(retryTimer);
            retryTimer = null;
        }
    }

    function cancelarFeedbackPendiente() {
        feedbackCompletionToken++;

        cancelarReintentoPendiente();

        if (feedbackTimer) {
            clearTimeout(feedbackTimer);
            feedbackTimer = null;
        }

        if (window.speechSynthesis) {
            window.speechSynthesis.cancel();
        }
    }

    async function responder(respuesta, button, current) {
        if (answered) return;

        answered = true;


        const respuestasCorrectas = Array.isArray(current.correctAnswers) && current.correctAnswers.length
            ? current.correctAnswers
            : [current.correctAnswer];

        const textoRespuestas = respuestasCorrectas.join(', ');
        const verboRespuesta = respuestasCorrectas.length > 1 ? 'Son' : 'Es';

        const feedbackToken = ++feedbackCompletionToken;

        const onFeedbackComplete = (exito) => {
            if (
                feedbackToken !== feedbackCompletionToken ||
                !answered
            ) {
                return;
            }

            programarAutoNext(exito ? 0 : 1500);
        };

        const mostrarFeedback = (esCorrecta, onComplete) => {
            feedbackTitle.textContent = esCorrecta ? '✅ Muy bien.' : '❌ Incorrecto.';
            feedbackText.textContent = `${verboRespuesta} ${textoRespuestas}`;
            return reproducirFeedback(
                `${esCorrecta ? 'Muy bien' : 'Incorrecto'}. ${verboRespuesta}`,
                textoRespuestas,
                current.answerLanguage || 'en-US',
                onComplete
            );
        };

        const correcta = respuestasCorrectas.some(
            respuestaCorrecta =>
                normalizarRespuesta(respuesta) === normalizarRespuesta(respuestaCorrecta)
        );

        if (!current.resultSaved) {
            current.resultSaved = true;

            try {
                await guardarResultado(current, respuesta);
            } catch (error) {
                console.error('ERROR GUARDANDO RESPUESTA:', error);
            }
        }

        const botones = options.querySelectorAll('button');
        const inputRespuesta = options.querySelector('.english-practice-answer-input');

        if (correcta) {
            score++;
            reproducirSonidoCorrecto();

            const respuestasCorrectasNormalizadas = respuestasCorrectas.map(normalizarRespuesta);

            botones.forEach(boton => {
                boton.disabled = true;

                if (respuestasCorrectasNormalizadas.includes(normalizarRespuesta(boton.textContent))) {
                    boton.classList.add('correct');
                }
            });

            if (inputRespuesta) {
                inputRespuesta.disabled = true;
                inputRespuesta.classList.add('correct');
            }

            if (button) button.classList.add('correct');

            const feedbackStarted = mostrarFeedback(true, onFeedbackComplete);

            feedback.style.display = 'block';
            nextButton.style.display = 'inline-flex';

            if (!feedbackStarted) {
                programarAutoNext(1500);
            }

            return;
        }

        reproducirSonidoIncorrecto();

        cancelarReintentoPendiente();

        const respuestasCorrectasNormalizadas = respuestasCorrectas.map(normalizarRespuesta);

        botones.forEach(boton => {
            boton.disabled = true;

            if (respuestasCorrectasNormalizadas.includes(normalizarRespuesta(boton.textContent))) {
                boton.classList.add('correct');
            }
        });

        if (inputRespuesta) {
            inputRespuesta.disabled = true;
            inputRespuesta.classList.add('incorrect');
        }

        if (button) button.classList.add('incorrect');

        const esPreguntaEscrita =
            current.type === 'listening' ||
            current.type === 'english-meaning' ||
            current.type === 'spanish-word';

        const feedbackStarted = mostrarFeedback(
            false,
            esPreguntaEscrita ? null : onFeedbackComplete
        );

        feedback.style.display = 'block';

        if (!esPreguntaEscrita) {
            nextButton.style.display = 'inline-flex';

            if (!feedbackStarted) {
                programarAutoNext(1500);
            }

            return;
        }

        nextButton.style.display = 'none';

        retryTimer = setTimeout(() => {
            retryTimer = null;

            if (current !== questions[currentQuestionIndex]) return;

            botones.forEach(boton => {
                boton.disabled = false;
                boton.classList.remove('incorrect');
            });

            if (inputRespuesta) {
                inputRespuesta.disabled = false;
                inputRespuesta.classList.remove('incorrect');
                inputRespuesta.value = '';
                inputRespuesta.focus();
            }

            answered = false;
        }, 900);
    }

    function avanzarSiguiente() {
        if (autoNextTimer) {
            clearTimeout(autoNextTimer);
            autoNextTimer = null;
        }


        cancelarFeedbackPendiente();
        currentQuestionIndex++;
        mostrarPregunta();
    }

    if (nextButton) {
        nextButton.addEventListener('click', () => {
            avanzarSiguiente();
        });
    }

    async function finalizarSesion() {
        const response = await fetch(`/english/category/${practice.categoryId}/practice/finish`, {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
                'Accept': 'application/json',
                'X-CSRF-TOKEN': document.querySelector('meta[name="csrf-token"]').getAttribute('content')
            },
            body: JSON.stringify({
                practice_session_id: practice.sessionId
            })
        });

        if (!response.ok) throw new Error('No se pudo finalizar la práctica.');

        return response.json();
    }

    async function finalizarPractica() {
        try {

            const resultado = await finalizarSesion();

            practiceCard.style.display = 'none';
            practiceResult.style.display = 'block';
            resultCategoryElement.textContent = practice.categoryName;
            correctAnswersElement.textContent = resultado.correct_answers;
            incorrectAnswersElement.textContent = resultado.incorrect_answers;
            scoreElement.textContent = `${resultado.score}%`;

            const percentage = resultado.score;

            if (percentage >= 90) {
                resultMessageElement.textContent = '🏆 ¡Excelente trabajo!';
            } else if (percentage >= 70) {
                resultMessageElement.textContent = '👏 ¡Muy bien! Sigue practicando.';
            } else if (percentage >= 50) {
                resultMessageElement.textContent = '💪 Vas por buen camino. Puedes mejorar.';
            } else {
                resultMessageElement.textContent = '📚 Sigue estudiando y vuelve a intentarlo.';
            }
        } catch (error) {
            console.error('ERROR DENTRO DE finalizarPractica:', error);
            alert('ERROR: ' + error.message);
        }
    }

    async function reiniciarPractica() {
        if (autoNextTimer) {
            clearTimeout(autoNextTimer);
            autoNextTimer = null;
        }

        cancelarFeedbackPendiente();


        practice.sessionId = crypto.randomUUID();
        currentQuestionIndex = 0;
        score = 0;
        answered = false;
        questions = generarPreguntas();

        if (questions.length === 0) {
            alert('No hay suficientes preguntas para practicar.');
            return;
        }

        try {
            await iniciarSesion();
            practiceResult.style.display = 'none';
            modeSelector.style.display = 'none';
            practiceCard.style.display = 'block';
            mostrarPregunta();
        } catch (error) {
            console.error(error);
            alert('No se pudo iniciar la nueva práctica.');
        }
    }

    if (retryButton) {
        retryButton.addEventListener('click', () => {
            reiniciarPractica();
        });
    }

    function volverAlSelector() {
        if (autoNextTimer) {
            clearTimeout(autoNextTimer);
            autoNextTimer = null;
        }

        cancelarFeedbackPendiente();


        questions = [];
        currentQuestionIndex = 0;
        score = 0;
        answered = false;

        if (practiceCard) practiceCard.style.display = 'none';
        if (practiceResult) practiceResult.style.display = 'none';
        if (modeSelector) modeSelector.style.display = 'block';

        if (questionType) {
            questionType.style.display = '';
            questionType.textContent = '';
        }

        if (question) {
            question.style.display = '';
            question.textContent = '';
        }

        if (options) {
            options.style.display = '';
            options.innerHTML = '';
        }

        if (listenContainer) {
            listenContainer.style.display = 'none';
            listenContainer.innerHTML = '';
        }

        if (feedback) feedback.style.display = 'none';
        if (nextButton) nextButton.style.display = 'none';

        practice.sessionId = crypto.randomUUID();
    }

    if (changeModeButton) {
        changeModeButton.addEventListener('click', () => {
            volverAlSelector();

            modeOptions.forEach(option => {
                option.classList.remove('selected');
            });

            selectedPracticeMode = null;
            practice.selectedMode = null;

            if (startButton) startButton.disabled = true;

            autoNextEnabled = true;

            if (autoNextButton) {
                autoNextButton.textContent = '⚡ Auto: ON';
                autoNextButton.setAttribute('aria-pressed', 'true');
                autoNextButton.classList.remove('disabled');
            }
        });
    }

    if (exitPracticeButton) {
        exitPracticeButton.addEventListener('click', () => {
            volverAlSelector();

            modeOptions.forEach(option => {
                option.classList.remove('selected');
            });

            selectedPracticeMode = null;
            practice.selectedMode = null;

            if (startButton) startButton.disabled = true;
        });
    }


    function reproducirPalabra(palabra) {
        if (!palabra) return;



        if (typeof window.reproducirPronunciacion === 'function') {
            setTimeout(() => {
                window.reproducirPronunciacion(palabra);
            }, 100);
        }
    }



    function reproducirFeedback(
        prefijo,
        respuestas,
        idiomaRespuestas = 'en-US',
        onComplete = null
    ) {
        if (!practiceSoundsEnabled || !prefijo) {
            return false;
        }

        if (
            typeof window.reproducirPronunciacionSegmentos !== 'function' ||
            !window.speechSynthesis ||
            typeof SpeechSynthesisUtterance === 'undefined'
        ) {
            return false;
        }

        if (feedbackTimer) {
            clearTimeout(feedbackTimer);
        }

        feedbackTimer = setTimeout(() => {
            feedbackTimer = null;

            if (!practiceSoundsEnabled) {
                if (typeof onComplete === 'function') {
                    onComplete(false);
                }

                return;
            }

            const iniciado =
                window.reproducirPronunciacionSegmentos(
                    [
                        {
                            texto: prefijo,
                            idioma: 'es-ES'
                        },
                        {
                            texto: respuestas,
                            idioma: idiomaRespuestas
                        }
                    ],
                    (exito) => {
                        if (typeof onComplete === 'function') {
                            onComplete(exito);
                        }
                    }
                );

            if (
                !iniciado &&
                typeof onComplete === 'function'
            ) {
                onComplete(false);
            }
        }, 150);

        return true;
    }


    if (startButton) {
        startButton.addEventListener('click', async () => {
            if (!practice.selectedMode) return;

            try {
                startButton.disabled = true;
                questions = generarPreguntas();

                if (questions.length === 0) {
                    alert('No hay suficientes preguntas para practicar.');
                    return;
                }

                practice.sessionId = crypto.randomUUID();
                await iniciarSesion();

                currentQuestionIndex = 0;
                score = 0;
                answered = false;
                modeSelector.style.display = 'none';
                practiceResult.style.display = 'none';
                practiceCard.style.display = 'block';
                questionType.style.display = '';
                question.style.display = '';
                options.style.display = '';
                mostrarPregunta();
            } catch (error) {
                console.error('ERROR AL INICIAR:', error);
                alert('No se pudo iniciar la práctica: ' + error.message);
            } finally {
                startButton.disabled = !practice.selectedMode;
            }
        });
    }

    if (autoNextButton) {
        autoNextButton.addEventListener('click', () => {
            autoNextEnabled = !autoNextEnabled;
            autoNextButton.setAttribute('aria-pressed', autoNextEnabled ? 'true' : 'false');

            if (autoNextEnabled) {
                autoNextButton.textContent = '⚡ Auto: ON';
                autoNextButton.classList.remove('disabled');
            } else {
                autoNextButton.textContent = '⏸ Auto: OFF';
                autoNextButton.classList.add('disabled');

                if (autoNextTimer) {
                    clearTimeout(autoNextTimer);
                    autoNextTimer = null;
                }
            }
        });
    }
})();

