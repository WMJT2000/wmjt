
@extends('layouts.app')

@section('title', 'Practicar ' . $category->name)

@section('content')

    <div class="english-container">

        <div class="english-header">
            <div>
                <h1>
                    🧠 Practicar {{ $category->name }}
                </h1>

                <p>
                    Pon a prueba lo que has aprendido.
                </p>
            </div>

            <div>
                <a
                    href="{{ route('english.index') }}"
                    class="english-mastery-back-button"
                >
                    ← Volver a Inglés
                </a>
            </div>
        </div>

        @if ($words->count() > 0)

            <button
                type="button"
                id="btn-toggle-practice-sounds"
                class="english-practice-sound-toggle"
                aria-pressed="false">
                🔊 Sonidos
            </button>

            <div
                id="practice-mode-selector"
                class="english-practice-mode-selector">

                <div class="english-practice-mode-header">
                    <h2>
                        ¿Cómo quieres practicar?
                    </h2>

                    <p>
                        Elige el tipo de ejercicio.
                    </p>
                </div>

                <div class="english-practice-mode-options">

                    {{-- INGLÉS → ESPAÑOL --}}
                    <button
                        type="button"
                        class="english-practice-mode-option"
                        data-practice-mode="english-spanish">

                        <span class="english-practice-mode-icon">
                            🇬🇧
                        </span>

                        <span class="english-practice-mode-content">
                            <strong>
                                Inglés → Español
                            </strong>

                            <small>
                                Mira la palabra en inglés y elige su significado.
                            </small>
                        </span>

                    </button>


                    {{-- ESPAÑOL → INGLÉS --}}
                    <button
                        type="button"
                        class="english-practice-mode-option"
                        data-practice-mode="spanish-english">

                        <span class="english-practice-mode-icon">
                            🇪🇸
                        </span>

                        <span class="english-practice-mode-content">
                            <strong>
                                Español → Inglés
                            </strong>

                            <small>
                                Mira el significado en español y elige la palabra.
                            </small>
                        </span>

                    </button>


                    {{-- ESCUCHAR → ESCRIBIR --}}
                    <button
                        type="button"
                        class="english-practice-mode-option"
                        data-practice-mode="listening">

                        <span class="english-practice-mode-icon">
                            🔊
                        </span>

                        <span class="english-practice-mode-content">
                            <strong>
                                Escuchar → Escribir
                            </strong>

                            <small>
                                Escucha la pronunciación y escribe la palabra que escuchaste.
                            </small>
                        </span>

                    </button>


                    {{-- INGLÉS → ESCRIBIR SIGNIFICADO --}}
                    <button
                        type="button"
                        class="english-practice-mode-option"
                        data-practice-mode="english-meaning">

                        <span class="english-practice-mode-icon">
                            ✍️
                        </span>

                        <span class="english-practice-mode-content">
                            <strong>
                                Inglés → Escribir significado
                            </strong>

                            <small>
                                Mira la palabra en inglés y escribe su significado en español.
                            </small>
                        </span>

                    </button>


                    {{-- ESPAÑOL → ESCRIBIR INGLÉS --}}
                    <button
                        type="button"
                        class="english-practice-mode-option"
                        data-practice-mode="spanish-word">

                        <span class="english-practice-mode-icon">
                            ✍️
                        </span>

                        <span class="english-practice-mode-content">
                            <strong>
                                Español → Escribir inglés
                            </strong>

                            <small>
                                Mira el significado en español y escribe la palabra en inglés.
                            </small>
                        </span>

                    </button>


                    {{-- MODO MEZCLADO --}}
                    <button
                        type="button"
                        class="english-practice-mode-option"
                        data-practice-mode="mixed">

                        <span class="english-practice-mode-icon">
                            🎲
                        </span>

                        <span class="english-practice-mode-content">
                            <strong>
                                Mezclado
                            </strong>

                            <small>
                                Combina los diferentes tipos de preguntas.
                            </small>
                        </span>

                    </button>


                    {{-- REPETIR INCORRECTAS --}}
                    <button
                        type="button"
                        class="english-practice-mode-option"
                        data-practice-mode="incorrect"
                        @if (count($incorrectWordIds) === 0) disabled @endif>

                        <span class="english-practice-mode-icon">
                            🔄
                        </span>

                        <span class="english-practice-mode-content">
                            <strong>
                                Repetir incorrectas
                            </strong>

                            <small>
                                @if (count($incorrectWordIds) > 0)
                                    Practica las palabras que has fallado anteriormente.
                                @else
                                    Todavía no tienes palabras incorrectas.
                                @endif
                            </small>
                        </span>

                        @if (count($incorrectWordIds) > 0)
                            <span class="english-practice-mode-count">
                                {{ count($incorrectWordIds) }}
                            </span>
                        @endif

                    </button>

                </div>


                <div class="english-practice-question-count">

                    <div class="english-practice-mode-header">

                        <h2>
                            ¿Cuántas preguntas quieres?
                        </h2>

                        <p>
                            Elige la cantidad de preguntas para esta práctica.
                        </p>

                    </div>

                    <div class="english-practice-question-count-options">

                        <button
                            type="button"
                            class="english-practice-question-count-option selected"
                            data-question-count="10">
                            10
                        </button>

                        <button
                            type="button"
                            class="english-practice-question-count-option"
                            data-question-count="20">
                            20
                        </button>

                        <button
                            type="button"
                            class="english-practice-question-count-option"
                            data-question-count="30">
                            30
                        </button>

                    </div>

                </div>


                <button
                    type="button"
                    id="btn-start-practice"
                    class="english-practice-start-button"
                    disabled>

                    Comenzar práctica →

                </button>

            </div>


            <div
                id="practice-card"
                class="english-practice-card"
                style="display: none;">

                <div class="english-practice-progress">

                    <span>
                        Pregunta
                    </span>

                    <strong id="practice-progress">
                        1 / 10
                    </strong>

                </div>


                <div class="english-practice-question">

                    <span
                        id="practice-question-type"
                        class="english-practice-question-type">
                    </span>

                    <h2 id="practice-question"></h2>

                    <div
                        id="practice-listen"
                        class="english-practice-listen-container"
                        style="display: none;">
                    </div>

                </div>


                <div
                    id="practice-options"
                    class="english-practice-options">
                </div>


                <div
                    id="practice-feedback"
                    class="english-practice-feedback"
                    style="display: none;">

                    <strong id="practice-feedback-title"></strong>

                    <p id="practice-feedback-text"></p>

                </div>


                <div class="english-practice-actions">

                    <button
                        type="button"
                        id="btn-exit-practice"
                        class="english-practice-change-mode-button-2">

                        ← Salir de la práctica

                    </button>


                    <button
                        type="button"
                        id="btn-toggle-auto-next"
                        class="english-practice-auto-next-button"
                        aria-pressed="true">

                        ⚡ Auto: ON

                    </button>


                    <button
                        type="button"
                        id="btn-next-practice"
                        style="display: none;">

                        Siguiente →

                    </button>

                </div>

            </div>


            <div
                id="practice-result"
                class="english-practice-result"
                style="display: none;">

                <h2>
                    🎉 ¡Práctica terminada!
                </h2>


                <div class="english-practice-summary">

                    <p>
                        <strong>
                            Categoría:
                        </strong>

                        <span id="practice-result-category"></span>
                    </p>


                    <p>
                        <strong>
                            Correctas:
                        </strong>

                        <span id="practice-correct-answers">
                            0
                        </span>
                    </p>


                    <p>
                        <strong>
                            Incorrectas:
                        </strong>

                        <span id="practice-incorrect-answers">
                            0
                        </span>
                    </p>


                    <p>
                        <strong>
                            Puntaje:
                        </strong>

                        <span id="practice-score">
                            0%
                        </span>
                    </p>

                </div>


                <p id="practice-result-message"></p>


                <div class="english-practice-result-actions">

                    <button
                        type="button"
                        id="btn-retry-practice"
                        class="english-practice-retry-button">

                        🔄 Intentar nuevamente

                    </button>


                    <button
                        type="button"
                        id="btn-change-practice-mode"
                        class="english-practice-change-mode-button">

                        🔄 Cambiar modo

                    </button>


                    <a
                        href="{{ route('english.study', $category) }}"
                        class="english-practice-study-link">

                        📚 Volver a estudiar

                    </a>

                </div>

            </div>


        @else

            <div class="english-empty">

                @if ($practiceEmptyMessage)

                    <strong>
                        🎉 ¡Muy bien!
                    </strong>

                    <span>
                        {{ $practiceEmptyMessage }}
                    </span>

                    <a
                        href="{{ route('english.mastery', $category) }}"
                        class="english-practice-empty-button">

                        ← Volver al dominio

                    </a>

                @else

                    <strong>
                        Esta categoría todavía no tiene palabras.
                    </strong>

                    <span>
                        Agrega palabras antes de comenzar a practicar.
                    </span>

                @endif

            </div>

        @endif

    </div>


    <script>
        window.englishPractice = {
            words: @json($words),
            incorrectWordIds: @json($incorrectWordIds),
            wordPracticeStats: @json($wordPracticeStats),
            categoryId: {{ $category->id }},
            categoryName: @json($category->name),
            questionCount: 10,
            selectedMode: null,
            sessionId: crypto.randomUUID()
        };
    </script>

@endsection

